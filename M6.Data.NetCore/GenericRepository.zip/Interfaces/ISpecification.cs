﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace M6.Business.GenericRepository.Interfaces
{
    
    public interface ISpecification<T>
    {
        Expression<Func<T, bool>> Sql { get; }
        List<Expression<Func<T, object>>> Includes { get; }
        List<string> IncludeStrings { get; }
    }

}
