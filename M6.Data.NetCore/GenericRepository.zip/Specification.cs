﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using M6.Business.GenericRepository.Interfaces;
namespace M6.Business.GenericRepository
{
    
    public abstract class Specification<T> : ISpecification<T>
    {
        public Specification(Expression<Func<T, bool>> Sql)
        {
            Sql = Sql;
        }
        public Expression<Func<T, bool>> Sql { get; }
        public List<Expression<Func<T, object>>> Includes { get; } = new List<Expression<Func<T, object>>>();
        public List<string> IncludeStrings { get; } = new List<string>();

        protected virtual void AddInclude(Expression<Func<T, object>> includeExpression)
        {
            Includes.Add(includeExpression);
        }
        // string-based includes allow for including children of children, e.g. Basket.Items.Product
        protected virtual void AddInclude(string includeString)
        {
            IncludeStrings.Add(includeString);
        }
    }
}
