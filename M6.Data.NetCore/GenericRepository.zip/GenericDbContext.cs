﻿using Microsoft.EntityFrameworkCore;
using M6.Data.Models;
using System.Reflection.Metadata;

namespace M6.Business.GenericRepository
{
    public class GenericDbContext : DbContext
    {
        //const string  connectionString= @"Data Source=DESKTOP-GUKSU2D\SQLEXPRESS;Initial Catalog=Northwind;Integrated Security=True";
        const string connectionString = @"Data Source=172.17.6.65,1942;Initial Catalog=M6;Persist Security Info=True;User ID=mode_jun;Password=M0detour!!";

        public GenericDbContext() :base() { }
        public GenericDbContext(DbContextOptions<GenericDbContext> options) : base(options)  {  }
        //public DbSet<Categories> Categories { get;set;}
        //public DbSet<Categories> Categories { get; set; }
        public DbSet<공항> 공항 { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(connectionString);
        }
    }
}